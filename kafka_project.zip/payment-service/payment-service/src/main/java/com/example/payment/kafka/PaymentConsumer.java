package com.example.payment.kafka;

import com.example.order.model.OrderEvent;
import com.example.payment.model.PaymentEvent;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class PaymentConsumer {

    private static final String PAYMENT_TOPIC = "payment-processed";

    private final KafkaTemplate<String, PaymentEvent> kafkaTemplate;

    public PaymentConsumer(KafkaTemplate<String, PaymentEvent> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    @KafkaListener(topics = "order-placed", groupId = "payment-group")
    public void processPayment(OrderEvent order) {
        System.out.println("Payment service received order: " + order);

        boolean paymentSuccess = order.getTotalAmount() < 10000; 

        PaymentEvent paymentEvent = new PaymentEvent(
            order.getOrderId(),
            order.getTotalAmount(),
            paymentSuccess ? "SUCCESS" : "FAILED",
            paymentSuccess ? "Payment processed successfully" : "Payment declined"
        );

        System.out.println("Publishing payment result: " + paymentEvent);
        kafkaTemplate.send(PAYMENT_TOPIC, order.getOrderId(), paymentEvent);
    }
}