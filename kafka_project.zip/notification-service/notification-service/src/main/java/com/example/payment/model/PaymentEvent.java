package com.example.payment.model;

public class PaymentEvent {

    private String orderId;        
    private double amount;         
    private String paymentStatus;  
    private String message;        

    public PaymentEvent() {}

    public PaymentEvent(String orderId, double amount,
                        String paymentStatus, String message) {
        this.orderId = orderId;
        this.amount = amount;
        this.paymentStatus = paymentStatus;
        this.message = message;
    }

    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public String getPaymentStatus() { return paymentStatus; }
    public void setPaymentStatus(String paymentStatus) { this.paymentStatus = paymentStatus; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    @Override
    public String toString() {
        return "PaymentEvent{orderId='" + orderId + "', amount=" + amount +
               ", status='" + paymentStatus + "'}";
    }
}