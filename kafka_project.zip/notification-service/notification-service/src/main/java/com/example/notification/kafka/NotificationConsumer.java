package com.example.notification.kafka;

import com.example.payment.model.PaymentEvent;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class NotificationConsumer {

    @KafkaListener(topics = "payment-processed", groupId = "notification-group")
    public void sendNotification(PaymentEvent payment) {
        System.out.println("Notification service received payment event: " + payment);

        if ("SUCCESS".equals(payment.getPaymentStatus())) {
            System.out.println("✅ EMAIL SENT: Dear customer, your order " 
                + payment.getOrderId() 
                + " is confirmed! Amount charged: ₹" 
                + payment.getAmount());
        } else {
            System.out.println("❌ EMAIL SENT: Dear customer, payment for order " 
                + payment.getOrderId() 
                + " failed. Please retry.");
        }
    }
}