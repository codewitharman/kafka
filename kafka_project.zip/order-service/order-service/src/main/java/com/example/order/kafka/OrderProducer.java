package com.example.order.kafka;

import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.example.order.model.OrderEvent;

@Service
public class OrderProducer {

	private static final String TOPIC = "order-placed";

	private final KafkaTemplate<String, OrderEvent> kafkaTemplate;

	public OrderProducer(KafkaTemplate<String, OrderEvent> kafkaTemplate) {
		this.kafkaTemplate = kafkaTemplate;
	}

	public void sendOrder(OrderEvent event) {
		System.out.println("Sending order to kafka: " + event);
		kafkaTemplate.send(TOPIC, event.getOrderId(), event);
	}
}
