package com.example.order.model;

public class OrderEvent {
	private String orderId;
	private String productName;
	private int quantity;
	private double totalAmount;
	private String status;

	public OrderEvent() {
	}

	public OrderEvent(String orderId, String productName, int quantity, double totalAmount, String status) {
		this.orderId = orderId;
		this.productName = productName;
		this.quantity = quantity;
		this.totalAmount = totalAmount;
		this.status = status;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "OrderEvent{orderId='" + orderId + "', product='" + productName + "', qty=" + quantity + ", amount="
				+ totalAmount + ", status='" + status + "'}";
	}
}