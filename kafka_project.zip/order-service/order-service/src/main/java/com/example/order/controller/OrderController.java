package com.example.order.controller;

import com.example.order.kafka.OrderProducer;
import com.example.order.model.OrderEvent;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.UUID;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private final OrderProducer orderProducer;

    public OrderController(OrderProducer orderProducer) {
        this.orderProducer = orderProducer;
    }

    @PostMapping
    public ResponseEntity<String> placeOrder(@RequestBody OrderEvent order) {
        order.setOrderId(UUID.randomUUID().toString());
        order.setStatus("PLACED");
        orderProducer.sendOrder(order);
        return ResponseEntity.ok("Order placed! ID: " + order.getOrderId());
    }
}